﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeePresswoodSnakeFinalProject
{
    class GameTile
    {
        public int x, y;

        public GameTile(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
    }
}
